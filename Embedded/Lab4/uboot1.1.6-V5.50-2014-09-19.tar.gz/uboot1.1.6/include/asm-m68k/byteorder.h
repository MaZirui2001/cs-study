#ifndef _M68K_BYTEORDER_H
#define _M68K_BYTEORDER_H

#include <asm/types.h>
#include <linux/byteorder/big_endian.h>

#endif /* _M68K_BYTEORDER_H */
