#define U_BOOT_VERSION "U-Boot 1.1.6"
