/* Automatically generated - do not edit */
#define FORLINX_BOOT_NAND
#define FORLINX_BOOT_RAM256
#include <configs/smdk6410.h>
